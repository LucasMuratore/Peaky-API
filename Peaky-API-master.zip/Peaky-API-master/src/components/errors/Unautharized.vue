<template>
  <div>
    <p>UNATHORIZED</p>
    <!--<button>LOGUEATE</button> -->
  </div>
</template>

<script>
export default {
  name: "Unauthorized",
};
</script>